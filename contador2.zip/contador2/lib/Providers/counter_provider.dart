import 'package:flutter/material.dart';

class CounterProvider with ChangeNotifier{
  int _counter = 0;
  // ignore: prefer_final_fields
  int  _color = Colors.green.value;

  int get counter => _counter;
  // ignore: unused_element, recursive_getters
  int get color => _color;

  void increment(){
    _counter++;
    notifyListeners();
  }

  void decrement(){
    _counter--;
    notifyListeners();
  }

  void restart(){
    _counter = 0;
    notifyListeners();
  }

  void multi(int temp){
    _counter *= temp;
    notifyListeners();
  }

  void changeColor() {
    int flag = 0;

    if(_counter == 0){
      Colors.grey.value;
      flag = 1;
    }
    for(int i = 2; i <= _counter / 2; i++){
      if(_counter % i == 0){
        _color = Colors.green.value;
        flag = 1;
      }
    }

    if(flag == 0)_color = Colors.blue.value;
    notifyListeners();
  }

}