
import 'package:contador2/Providers/counter_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class Primo extends StatefulWidget {
  const Primo({super.key});

  @override
  State<Primo> createState() => _Primo();
}

class _Primo extends State<Primo> {
  //int cola = 5;
  @override
  Widget build(BuildContext context) {
    int cola = context.watch<CounterProvider>().color;
    return  Center(
      child: Text(
            'Primo', 
            style:  TextStyle(
              fontSize: 40,
              color: Color(cola)
              ),
      )
    );
  }
}

//context.read<CounterProvider>().changeColor()