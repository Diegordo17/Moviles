import 'package:contador2/Providers/counter_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Multiplica extends StatefulWidget {
  const Multiplica({super.key});

  @override
  State<Multiplica> createState() => _Multiplica();
}

class _Multiplica extends State<Multiplica> {
  @override
  Widget build(BuildContext context) {
    return  Center(
      child: Column(
        children: [
          Text(
            context.watch<CounterProvider>().counter.toString(), 
            style: const TextStyle(fontSize: 40),),
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    context.read<CounterProvider>().multi(2);
                  },
                  child: const Text('x2'),
                ),
                ElevatedButton(
                  onPressed: () {
                    context.read<CounterProvider>().multi(3);
                  },
                  child: const Text('x3'),
                ),

                ElevatedButton(
                  onPressed: () {
                    context.read<CounterProvider>().multi(5);
                  },
                  child: const Text('x5'),
                ),
              ],
            ),
          ),
          
        ],
      )
    );
  }
}
