package com.example.contador2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
