package com.example.tarea1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
