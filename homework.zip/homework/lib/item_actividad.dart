import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ItemActividad extends StatelessWidget {
  String cola;
  String foto;
  String nombre;
  ItemActividad({super.key, required  this.cola, required this.foto, required this.nombre} );

  @override
  Widget build(BuildContext context) {
    
   
    return Container(
      padding: EdgeInsets.all(8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 120,
            width: 120, 
            color: Colors.purple,
            child: Image.asset(
              this.foto,
              fit: BoxFit.cover
            ),
          ),
          Text(this.cola, style: TextStyle(fontSize: 11)),
          Text(this.nombre),
        ],
      ),
    );
  }

  
}
