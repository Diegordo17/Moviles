# Tarea 3 base

App para practicar los siguientes temas:
- Filas, Columnas
- Alineacion de elementos
- Imagenes
- Textos y estilos
- Overflow de pixeles*

## Getting Started

Recuerda que despues de clonar el proyecto, abrir una terminal **dentro** de la carpeta del proyecto y ejecutar el comando:

```sh
flutter packages get
``` 

## App Screenshot

<img src="screenshot/Capture0.png" width="240" height="480" />
<img src="screenshot/Capture1.png" width="240" height="480" />