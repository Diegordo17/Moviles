package com.example.info_lugar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
