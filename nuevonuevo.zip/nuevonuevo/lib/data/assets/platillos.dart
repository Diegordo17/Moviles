

const String platillos = '''[
  {
    "n": 1,
    "id": "hamburguesa",
    "time": "20 minutes",
    "ruta": "../lib/data/assets/burger.png",
    "simple": "simple",
    "Precio": "caro",
    "Ingredientes": "carne, pan, verdudas",
    "Pasos": "pon los ingredientes y cocina"
  },

  {
    "id": "pasta",
    "time": "50 minutes",
    "ruta": "../lib/data/assets/pasta.jpeg",
    "simple": "dificil",
    "Precio": "muy caro",
    "Ingredientes": "pasta y salsa",
    "Pasos": "pon los ingredientes y cocina"
  },

  {
    "id": "sandwich",
    "time": "5 minutes",
    "ruta": "../lib/data/assets/sandwich.jpeg",
    "simple": "simple",
    "Precio": "medio",
    "Ingredientes": "pan y lo demas",
    "Pasos": "pon los ingredientes y cocina"
  },

  {
    "id": "tacos",
    "time": "17 minutes",
    "ruta": "../lib/data/assets/tacos.jpeg",
    "simple": "simple",
    "Precio": "caro",
    "Ingredientes": "Carne y tortilla",
    "Pasos": "pon los ingredientes y cocina"
  }
]''';