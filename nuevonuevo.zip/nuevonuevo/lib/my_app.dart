
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:nuevonuevo/data/assets/platillos.dart';
import 'package:nuevonuevo/second_screen.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});
  
@override
  _State createState() => _State();

}

class _State extends State<HomePage>{
  List<dynamic> menu = [];

  @override
  void initState(){
    menu = jsonDecode(platillos);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Quick and easy')),
        backgroundColor: Colors.black,
      ),

      body: SecondScreen(menu: menu),
    );
  }
  
}



//MaterialPageRoute(builder: (context) => const SecondScreen())