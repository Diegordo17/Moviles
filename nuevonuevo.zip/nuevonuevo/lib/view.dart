
import 'package:flutter/material.dart';

class ViewScreen extends StatelessWidget {
  List<dynamic> menu;
  int index;
  ViewScreen({super.key, required this.menu, required this.index});

  @override
  Widget build(BuildContext context) {
    return Stack(
          children: <Widget>[
            Container(
              width: double.infinity, 
              height: 200,
              
              decoration:  BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(menu[index]["ruta"]), 
                  fit: BoxFit.cover, 
                ),
              ),
            ),
            Positioned(
              left: 0,
              top: 100,
              child: Container(
                width: 500, 
                height: 100, 
                color: Colors.black.withOpacity(0.5), 
                child: Center(
                  child: Text(
                    menu[index]["id"]  + '\n' + menu[index]["time"] + ' ' + menu[index]["simple"] + ' ' + menu[index]["Precio"],
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),

            Positioned(
    left: 0,
    top: 210, // Ajusta esta posición según tus necesidades
    child: Container(
      width: 500,
      height: 500,
      color: Colors.blue, // Cambia el color según tus preferencias
      child: Center(
        child: Text(
          'Receta'  + '\n' + menu[index]["Ingredientes"] + '\n' + 'Pasos' + '\n' + menu[index]["Pasos"],
          style: TextStyle(
            color: const Color.fromARGB(255, 0, 0, 0),
          ),


        ),
      ),
    ),
  ),

            ElevatedButton(
              onPressed: (){
                Navigator.pop(context, 
                MaterialPageRoute(builder: (context) => ViewScreen( menu: menu, index: index,))
                );
              },
              child: Text('Ver'),
            )
          ],
        );
    }
}

/*
return Stack(
          children: <Widget>[
            Container(
              width: double.infinity, 
              height: 200,
              
              decoration:  BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(menu[index]["ruta"]), 
                  fit: BoxFit.cover, 
                ),
              ),
            ),
            Positioned(
              left: 0,
              top: 100,
              child: Container(
                width: 500, 
                height: 100, 
                color: Colors.black.withOpacity(0.5), 
                child: Center(
                  child: Text(
                    menu[index]["id"]  + '\n' + menu[index]["time"] + ' ' + menu[index]["simple"] + ' ' + menu[index]["Precio"],
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => ViewScreen( menu: menu, index: index,))
                );
              },
              child: Text('cola'),
            )
          ],
        );
        
        return Container(
              width: 100, 
              height: 100,
              
              decoration:  BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(menu[index]["ruta"]), 
                  fit: BoxFit.cover, 
                ),
              ),
       );*/