
import 'package:flutter/material.dart';
import 'package:nuevonuevo/view.dart';

class SecondScreen extends StatelessWidget {
  
  final List<dynamic> menu;
  const  SecondScreen({
    super.key,
    required this.menu
    });

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: menu.length,
      separatorBuilder: (context, index) {
        
        return const Divider();
      },
      itemBuilder: (context, index) {
        
        return Stack(
          children: <Widget>[
            Container(
              width: double.infinity, 
              height: 200,
              
              decoration:  BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(menu[index]["ruta"]), 
                  fit: BoxFit.cover, 
                ),
              ),
            ),
            Positioned(
              left: 0,
              top: 100,
              child: Container(
                width: 500, 
                height: 100, 
                color: Colors.black.withOpacity(0.5), 
                child: Center(
                  child: Text(
                    menu[index]["id"]  + '\n' + menu[index]["time"] + ' ' + menu[index]["simple"] + ' ' + menu[index]["Precio"],
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => ViewScreen( menu: menu, index: index,))
                );
              },
              child: Text('Ver'),
            )
          ],
        );
      }
    );
}
}
