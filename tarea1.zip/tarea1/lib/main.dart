import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() => runApp(const MyApp());
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ejemplo de Provider',
      home: ChangeNotifierProvider(
        create: (_) => Counter(),
        child: const MyHomePage(),
      ),
    );
  }
}

class Counter extends ChangeNotifier {
  int count = 0;

  void increment() {
    count++;
    notifyListeners();
  }
}


class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final counter = Provider.of<Counter>(context);
    return MaterialApp(
      title: 'Material App',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Material App Bar'),
        ),
        body:  Center(
          child: Container(
            
            width: double.infinity,
            height: 170,
            decoration:  BoxDecoration(
              border: Border.all(
              color: Colors.black,
              width: 2,
              style: BorderStyle.solid,
              
            ),
          ),
  
          child: Column(
            children: [              
                Center(
                 child: Padding(
                   padding: const EdgeInsets.only(top:8.0),
                   child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                            Icons.account_circle,
                            size: 50,
                      ),
                      Text(counter.count.toString()),
                    ],
                                 ),
                 ),
               ),
               const Center(
                 child: Padding(
                   padding: EdgeInsets.only(top: 8.0),
                   child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('123 mainstreet'),
                      Text("455 60-78"),
                    ],
                                 ),
                 ),
               ),

               const Center(
                 child: Padding(
                   padding: EdgeInsets.only(top:12),
                   child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                            Icons.verified_user,
                            size: 25,
                            
                      ),
                 
                      Icon(
                            Icons.map,
                            size: 20,
                      ),
                 
                      Icon(
                            Icons.add_a_photo,
                            size: 15,
                            
                      ),
                      
                    ],
                                 ),
                 ),
               ),

               Center(
                child: MaterialButton(
                  color: Colors.green,
                  onPressed: counter.increment,
                  child: const Text('incrementar'),
                ),
               )

            ],
          ),

          
          
        ),

        

        
      ),
    )
    );
  }
}
